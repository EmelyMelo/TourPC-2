import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hd',
  templateUrl: './hd.component.html',
  styleUrls: ['./hd.component.css']
})
export class HdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
