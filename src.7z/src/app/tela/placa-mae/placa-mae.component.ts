import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-placa-mae',
  templateUrl: './placa-mae.component.html',
  styleUrls: ['./placa-mae.component.css']
})
export class PlacaMaeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
