import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-processador',
  templateUrl: './processador.component.html',
  styleUrls: ['./processador.component.css']
})
export class ProcessadorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
