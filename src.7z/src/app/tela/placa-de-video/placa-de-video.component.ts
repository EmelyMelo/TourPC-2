import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-placa-de-video',
  templateUrl: './placa-de-video.component.html',
  styleUrls: ['./placa-de-video.component.css']
})
export class PlacaDeVideoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
