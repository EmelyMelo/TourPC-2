import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-placa-de-rede',
  templateUrl: './placa-de-rede.component.html',
  styleUrls: ['./placa-de-rede.component.css']
})
export class PlacaDeRedeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
