import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-portas',
  templateUrl: './portas.component.html',
  styleUrls: ['./portas.component.css']
})
export class PortasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
