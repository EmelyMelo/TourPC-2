import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-placa-de-audio',
  templateUrl: './placa-de-audio.component.html',
  styleUrls: ['./placa-de-audio.component.css']
})
export class PlacaDeAudioComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
