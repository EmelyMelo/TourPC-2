import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fonte',
  templateUrl: './fonte.component.html',
  styleUrls: ['./fonte.component.css']
})
export class FonteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
