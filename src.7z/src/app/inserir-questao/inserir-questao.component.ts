import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inserir-questao',
  templateUrl: './inserir-questao.component.html',
  styleUrls: ['./inserir-questao.component.css']
})
export class InserirQuestaoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
