export class Usuario{
    nome: string;
    username: string;
    senha: string;
    tipoDeUsuario: string;

    constructor(){

    }

}