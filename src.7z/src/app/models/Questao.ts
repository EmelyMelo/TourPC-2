export class Questao{
    // checkbox assunto: 
    enunciado: String;
    // respostasPossiveis[];
    respostaCerta: String;
}